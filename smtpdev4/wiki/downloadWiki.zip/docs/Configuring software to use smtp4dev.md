smtp4dev should work with most software that sends messages using the SMTP protocol.

Configure your software to send mail to {"localhost"}. If the software requires an SSL connection then this must be enabled in the options dialog.