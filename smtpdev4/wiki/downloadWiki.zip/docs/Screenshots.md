## Version 1.1
![](Screenshots_mainform.png)

![](Screenshots_notify.png)