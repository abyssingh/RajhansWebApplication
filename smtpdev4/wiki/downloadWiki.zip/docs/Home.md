**Project Description**
Windows 7/Vista/XP/2003/2010 compatible dummy SMTP server. Sits in the system tray and does not deliver the received messages. The received messages can be quickly viewed, saved and the source/structure inspected. Useful for testing/debugging software that generates email.

[Screenshots](Screenshots) | [Configuring software to use smtp4dev](Configuring-software-to-use-smtp4dev) | [Building the source code](Building-the-source-code)

ESS 4 virus scanner reports the standalone binary release contains "MSIL/Injector.AN Trojan" virus. See the following link for details:
[http://smtp4dev.codeplex.com/workitem/5570](http://smtp4dev.codeplex.com/workitem/5570)

**Follow the development of smtp4dev version 3 at [https://github.com/rnwood/smtp4dev](https://github.com/rnwood/smtp4dev)**