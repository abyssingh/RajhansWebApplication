smtp4dev source code requires the following:
.NET 3.5 SP1 SDK,
WPF Toolkit ([http://www.codeplex.com/wpf](http://www.codeplex.com/wpf))

To build from Visual Studio just open the solution file and build. The project files are in 2008 format so should build in either VS2008 or VS2010.