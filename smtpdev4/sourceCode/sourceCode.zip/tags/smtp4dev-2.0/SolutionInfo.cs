﻿using System;
using System.Reflection;

[assembly: AssemblyCompany("Robert N Wood <rob@rnwood.co.uk>")]
[assembly: AssemblyProduct("smtp4dev")]
[assembly: AssemblyCopyright("Copyright © Robert N Wood 2009")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("2.0.5.0")]
[assembly: AssemblyFileVersion("2.0.5.0")]
