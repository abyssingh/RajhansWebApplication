.NETZ - .NET Executable Compressor
(c) 2004-present by Vasian Cepa

This software is provided "as is". It comes without absolutely no warranty.

Help and updates:

http://madebits.com/netz/index.php

EOF
