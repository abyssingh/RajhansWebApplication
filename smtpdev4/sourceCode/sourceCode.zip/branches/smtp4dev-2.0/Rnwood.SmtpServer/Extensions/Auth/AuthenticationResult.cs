namespace Rnwood.SmtpServer
{
    public enum AuthenticationResult
    {
        Success,
        Failure,
        TemporaryFailure
    }
}