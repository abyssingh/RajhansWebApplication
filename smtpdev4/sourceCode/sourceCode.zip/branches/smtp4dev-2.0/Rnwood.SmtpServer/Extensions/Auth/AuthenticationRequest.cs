﻿namespace Rnwood.SmtpServer.Extensions.Auth
{
    public interface IAuthenticationRequest
    {
    }
}