﻿namespace Rnwood.SmtpServer.Extensions.Auth
{
    public enum AuthMechanismProcessorStatus
    {
        Continue,
        Failed,
        Success
    }
}